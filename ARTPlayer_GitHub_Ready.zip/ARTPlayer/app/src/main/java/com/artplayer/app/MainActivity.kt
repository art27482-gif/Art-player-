package com.artplayer.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.Intent
import android.graphics.Bitmap
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.TrackSelectionParameters
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import java.util.Locale

private val Bg = Color(0xFF08090B)
private val Card = Color(0xFF12151A)
private val Purple = Color(0xFF8B3DFF)
private val Blue = Color(0xFF356BFF)

class MainActivity : ComponentActivity() {
    var player: ExoPlayer? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING)
        setContent { ARTPlayerApp() }
    }
    fun setBrightness(delta: Float) {
        val current = if (window.attributes.screenBrightness < 0) 0.5f else window.attributes.screenBrightness
        window.attributes = window.attributes.apply { screenBrightness = (current + delta).coerceIn(0.05f, 1f) }
    }
    fun changeVolume(delta: Int) {
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val current = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        audio.setStreamVolume(AudioManager.STREAM_MUSIC, (current + delta).coerceIn(0, max), 0)
    }
    fun fullscreen(enabled: Boolean) {
        if (Build.VERSION.SDK_INT >= 30) {
            window.insetsController?.let { controller ->
                if (enabled) controller.hide(WindowInsets.Type.systemBars()) else controller.show(WindowInsets.Type.systemBars())
                controller.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = if (enabled) 5894 else 0
        }
    }
    fun rotate() {
        requestedOrientation = if (resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE)
            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT else ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
    }
    override fun onDestroy() { player?.release(); player = null; super.onDestroy() }
}

@Composable
fun ARTPlayerApp() {
    val context = LocalContext.current
    val activity = context as MainActivity
    var selected by remember { mutableStateOf<VideoItem?>(null) }
    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Card, primary = Purple)) {
        if (selected == null) HomeScreen(onOpen = { selected = it })
        else PlayerScreen(item = selected!!, onBack = { selected = null }, activity = activity)
    }
}

@Composable
private fun HomeScreen(onOpen: (VideoItem) -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("art_player", Context.MODE_PRIVATE) }
    var hasPermission by remember { mutableStateOf(hasVideoPermission(context)) }
    var refresh by remember { mutableIntStateOf(0) }
    var search by remember { mutableStateOf("") }
    var favoritesOnly by remember { mutableStateOf(false) }
    var settings by remember { mutableStateOf(false) }
    var folderLabel by remember { mutableStateOf(prefs.getString("folder_label", "") ?: "") }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { hasPermission = it; refresh++ }
    val pickerLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { context.contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) ; onOpen(VideoItem(it, "فيديو مختار", 0L)) }
    }
    val folderLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        uri?.let {
            try { context.contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (_: Exception) {}
            prefs.edit().putString("folder_uri", it.toString()).putString("folder_label", DocumentFile.fromTreeUri(context, it)?.name ?: "مجلد مختار").apply()
            folderLabel = DocumentFile.fromTreeUri(context, it)?.name ?: "مجلد مختار"
            refresh++
        }
    }
    val videos = remember(hasPermission, refresh) { loadVideos(context) }
    val filtered = videos.filter { it.name.contains(search, true) && (!favoritesOnly || isFavorite(prefs, it.uri)) }

    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { folderLauncher.launch(null) }) { Icon(Icons.Default.Folder, "المجلدات") }
            Logo(); Spacer(Modifier.weight(1f))
            IconButton(onClick = { search = if (search.isEmpty()) " " else "" }) { Icon(Icons.Default.Search, "بحث") }
            IconButton(onClick = { settings = true }) { Icon(Icons.Default.Settings, "الإعدادات") }
        }
        if (folderLabel.isNotBlank()) Text("المجلد: $folderLabel", color = Color.Gray, modifier = Modifier.padding(horizontal = 18.dp))
        if (search.isNotEmpty()) {
            OutlinedTextField(value = search.trim(), onValueChange = { search = it }, modifier = Modifier.fillMaxWidth().padding(12.dp), singleLine = true, label = { Text("بحث عن فيديو") })
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !favoritesOnly, onClick = { favoritesOnly = false }, label = { Text("كل الفيديوهات") })
            FilterChip(selected = favoritesOnly, onClick = { favoritesOnly = true }, label = { Text("المفضلة ⭐") })
        }
        if (!hasPermission && videos.isEmpty()) {
            PermissionCard(onGrant = {
                val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE
                permissionLauncher.launch(permission)
            }, onPick = { pickerLauncher.launch(arrayOf("video/*")) })
        } else if (filtered.isEmpty()) EmptyState { pickerLauncher.launch(arrayOf("video/*")) }
        else VideoList(filtered, onOpen)
    }
    if (settings) SettingsDialog(prefs) { settings = false }
}


@Composable private fun Logo() = Text("ART", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.headlineMedium,
    modifier = Modifier.background(Brush.linearGradient(listOf(Purple, Blue)), RoundedCornerShape(12.dp)).padding(horizontal = 10.dp, vertical = 2.dp), color = Color.White)

@Composable private fun PermissionCard(onGrant: () -> Unit, onPick: () -> Unit) {
    Column(Modifier.padding(18.dp).fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Card).padding(22.dp)) {
        Text("اسمح لـ ART Player برؤية الفيديوهات", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp)); Text("سنستخدم الوصول لعرض فيديوهات جهازك وتشغيلها فقط.", color = Color.LightGray)
        Spacer(Modifier.height(18.dp)); Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { Button(onClick = onGrant) { Text("السماح") }; Button(onClick = onPick) { Text("اختيار فيديو") } }
    }
}
@Composable private fun EmptyState(onPick: () -> Unit) = Column(Modifier.fillMaxSize().padding(30.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
    Icon(Icons.Default.Folder, null, Modifier.size(70.dp), tint = Purple); Spacer(Modifier.height(14.dp)); Text("لا توجد فيديوهات", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(8.dp)); Text("اختر ملف فيديو من جهازك للبدء.", color = Color.Gray); Spacer(Modifier.height(18.dp)); Button(onClick = onPick) { Text("اختيار فيديو") }
}

@Composable private fun VideoList(videos: List<VideoItem>, onOpen: (VideoItem) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { items(videos, key = { it.uri.toString() }) { VideoRow(it, onOpen) } }
}
@Composable private fun VideoRow(video: VideoItem, onOpen: (VideoItem) -> Unit) {
    val context = LocalContext.current; val prefs = remember { context.getSharedPreferences("art_player", Context.MODE_PRIVATE) }
    var favorite by remember(video.uri) { mutableStateOf(isFavorite(prefs, video.uri)) }
    val bitmap = remember(video.uri) { loadThumbnail(context, video.uri) }
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Card).clickable { onOpen(video) }.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
        if (bitmap != null) Image(bitmap.asImageBitmap(), null, Modifier.size(120.dp, 76.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop)
        else Box(Modifier.size(120.dp, 76.dp).clip(RoundedCornerShape(12.dp)).background(Color.DarkGray), contentAlignment = Alignment.Center) { Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(36.dp)) }
        Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(video.name, maxLines = 2, fontWeight = FontWeight.SemiBold); Spacer(Modifier.height(5.dp)); Text(formatTime(video.duration), color = Color.Gray, style = MaterialTheme.typography.bodySmall) }
        IconButton(onClick = { favorite = !favorite; setFavorite(prefs, video.uri, favorite) }) { Icon(if (favorite) Icons.Default.Star else Icons.Default.StarBorder, "المفضلة", tint = if (favorite) Color.Yellow else Color.Gray) }
    }
}

@Composable private fun PlayerScreen(item: VideoItem, onBack: () -> Unit, activity: MainActivity) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("art_player", Context.MODE_PRIVATE) }
    val savedPosition = remember { prefs.getLong("pos_${item.uri}", 0L) }
    var subtitleUri by remember { mutableStateOf<Uri?>(null) }
    val subtitleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> subtitleUri = uri }
    val exo = remember(item.uri, subtitleUri) {
        ExoPlayer.Builder(context).build().apply {
            val builder = MediaItem.Builder().setUri(item.uri)
            subtitleUri?.let { builder.setSubtitleConfigurations(listOf(MediaItem.SubtitleConfiguration.Builder(it).setMimeType(MimeTypes.APPLICATION_SUBRIP).setLanguage("ar").setSelectionFlags(C.SELECTION_FLAG_DEFAULT).build())) }
            setMediaItem(builder.build()); prepare(); if (savedPosition > 0) seekTo(savedPosition); playWhenReady = true
        }
    }
    DisposableEffect(exo) { activity.player = exo; onDispose { prefs.edit().putLong("pos_${item.uri}", exo.currentPosition).apply(); exo.release(); activity.player = null } }
    var controls by remember { mutableStateOf(true) }; var locked by remember { mutableStateOf(false) }; var position by remember { mutableLongStateOf(savedPosition) }; var duration by remember { mutableLongStateOf(1L) }; var speed by remember { mutableFloatStateOf(1f) }; var menu by remember { mutableStateOf(false) }; var audioDialog by remember { mutableStateOf(false) }
    LaunchedEffect(exo) { while (true) { position = exo.currentPosition.coerceAtLeast(0); duration = exo.duration.takeIf { it > 0 } ?: 1L; delay(400) } }
    Box(Modifier.fillMaxSize().background(Color.Black).pointerInput(locked) { if (!locked) detectHorizontalDragGestures { _, dragAmount -> exo.seekTo((exo.currentPosition + (dragAmount * 20).toLong()).coerceIn(0, exo.duration.coerceAtLeast(0))) } }.pointerInput(locked) { if (!locked) detectVerticalDragGestures { change, dragAmount -> change.consume(); if (change.position.x < size.width / 2) activity.setBrightness(-dragAmount / size.height) else activity.changeVolume(if (dragAmount < 0) 1 else -1) } }.clickable { if (!locked) controls = !controls }) {
        AndroidView(factory = { PlayerView(it).apply { player = exo; useController = false; setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING) } }, modifier = Modifier.fillMaxSize())
        if (controls) {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .16f)))
            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "رجوع") }; Text(item.name, Modifier.weight(1f), maxLines = 1, fontWeight = FontWeight.SemiBold)
                IconButton(onClick = { locked = !locked }) { Icon(Icons.Default.Lock, "قفل") }
                IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "المزيد") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("السرعة: ${speed}x") }, leadingIcon = { Icon(Icons.Default.Speed, null) }, onClick = { speed = if (speed >= 2f) .5f else speed + .5f; exo.setPlaybackSpeed(speed); menu = false })
                    DropdownMenuItem(text = { Text("ملف الترجمة SRT") }, leadingIcon = { Icon(Icons.Default.Subtitles, null) }, onClick = { menu = false; subtitleLauncher.launch(arrayOf("text/srt", "application/x-subrip", "text/*")) })
                    DropdownMenuItem(text = { Text("الصوت") }, leadingIcon = { Icon(Icons.Default.VolumeUp, null) }, onClick = { menu = false; audioDialog = true })
                    DropdownMenuItem(text = { Text("تدوير الشاشة") }, leadingIcon = { Icon(Icons.Default.ScreenRotation, null) }, onClick = { menu = false; activity.rotate() })
                    DropdownMenuItem(text = { Text("ملء الشاشة") }, leadingIcon = { Icon(Icons.Default.Fullscreen, null) }, onClick = { menu = false; activity.fullscreen(true) })
                }
            }
            Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 18.dp, vertical = 20.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(formatTime(position)); Text(formatTime(duration)) }
                Slider(value = position.toFloat().coerceIn(0f, duration.toFloat()), onValueChange = { position = it.toLong() }, onValueChangeFinished = { exo.seekTo(position) }, modifier = Modifier.fillMaxWidth())
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { exo.seekBack() }) { Text("10") }; IconButton(onClick = { if (exo.isPlaying) exo.pause() else exo.play() }, modifier = Modifier.size(68.dp)) { Icon(if (exo.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "تشغيل", modifier = Modifier.size(50.dp), tint = Color.White) }; IconButton(onClick = { exo.seekForward() }) { Text("10") }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) { Text("${speed}x"); Icon(Icons.Default.Subtitles, "الترجمة"); Icon(Icons.Default.VolumeUp, "الصوت"); Icon(Icons.Default.ScreenRotation, "تدوير"); IconButton(onClick = { activity.fullscreen(true) }) { Icon(Icons.Default.Fullscreen, "ملء الشاشة") } }
            }
        }
        AnimatedVisibility(visible = locked, modifier = Modifier.align(Alignment.Center)) { Surface(shape = RoundedCornerShape(20.dp), color = Color.Black.copy(alpha = .65f)) { IconButton(onClick = { locked = false }) { Icon(Icons.Default.Lock, "فتح القفل", Modifier.size(42.dp)) } } }
    }
    if (audioDialog) AudioTrackDialog(exo) { audioDialog = false }
}

@Composable private fun AudioTrackDialog(exo: ExoPlayer, onClose: () -> Unit) {
    val groups = exo.currentTracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO }
    AlertDialog(onDismissRequest = onClose, title = { Text("مسار الصوت") }, text = {
        Column { if (groups.isEmpty()) Text("لا توجد مسارات صوت متعددة في هذا الفيديو.") else groups.forEachIndexed { gi, group -> group.mediaTrackGroup.let { trackGroup -> for (ti in 0 until trackGroup.length) { val format = trackGroup.getFormat(ti); TextButton(onClick = { exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon().setOverrideForType(TrackSelectionParameters.TrackSelectionOverride(trackGroup, ti)).build(); onClose() }) { Text(format.label ?: format.language ?: "مسار ${gi + 1}") } } } } }
    }, confirmButton = { TextButton(onClick = onClose) { Text("إغلاق") } })
}

@Composable private fun SettingsDialog(prefs: android.content.SharedPreferences, onClose: () -> Unit) {
    var autoResume by remember { mutableStateOf(prefs.getBoolean("auto_resume", true)) }
    AlertDialog(onDismissRequest = onClose, title = { Text("إعدادات ART Player") }, text = { Column { Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = autoResume, onCheckedChange = { autoResume = it; prefs.edit().putBoolean("auto_resume", it).apply() }); Text("استكمال الفيديو تلقائيًا") }; Text("يدعم التطبيق المفضلة، سجل موضع المشاهدة، SRT، مسارات الصوت، التدوير وملء الشاشة.", color = Color.Gray) } }, confirmButton = { TextButton(onClick = onClose) { Text("تم") } })
}

data class VideoItem(val uri: Uri, val name: String, val duration: Long)

private fun hasVideoPermission(context: Context): Boolean = ContextCompat.checkSelfPermission(context, if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
private fun loadVideos(context: Context): List<VideoItem> {
    val result = mutableListOf<VideoItem>()
    if (hasVideoPermission(context)) {
        val projection = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME, MediaStore.Video.Media.DURATION)
        context.contentResolver.query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, projection, null, null, "${MediaStore.Video.Media.DATE_ADDED} DESC")?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID); val nameCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME); val durationCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
            while (c.moveToNext()) { result += VideoItem(Uri.withAppendedPath(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, c.getLong(idCol).toString()), c.getString(nameCol) ?: "فيديو", c.getLong(durationCol)) }
        }
    }
    val tree = context.getSharedPreferences("art_player", Context.MODE_PRIVATE).getString("folder_uri", null)?.let(Uri::parse)
    tree?.let { DocumentFile.fromTreeUri(context, it)?.let { root -> collectTreeVideos(root, result) } }
    return result.distinctBy { it.uri.toString() }
}
private fun collectTreeVideos(dir: DocumentFile, out: MutableList<VideoItem>) { dir.listFiles().forEach { f -> if (f.isDirectory) collectTreeVideos(f, out) else if (f.isFile && (f.type?.startsWith("video/") == true || f.name?.matches(Regex(".*\\.(mp4|mkv|avi|mov|webm|3gp)$", true)) == true)) out += VideoItem(f.uri, f.name ?: "فيديو", 0L) } }
private fun loadThumbnail(context: Context, uri: Uri): Bitmap? = try { if (Build.VERSION.SDK_INT >= 29) context.contentResolver.loadThumbnail(uri, android.util.Size(480, 300), null) else null } catch (_: Exception) { null }
private fun formatTime(ms: Long): String { val total = (ms / 1000).coerceAtLeast(0); val h = total / 3600; val m = (total % 3600) / 60; val s = total % 60; return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s) else String.format(Locale.US, "%02d:%02d", m, s) }
private fun key(uri: Uri) = Uri.encode(uri.toString())
private fun isFavorite(prefs: android.content.SharedPreferences, uri: Uri) = prefs.getBoolean("fav_${key(uri)}", false)
private fun setFavorite(prefs: android.content.SharedPreferences, uri: Uri, value: Boolean) { prefs.edit().putBoolean("fav_${key(uri)}", value).apply() }
